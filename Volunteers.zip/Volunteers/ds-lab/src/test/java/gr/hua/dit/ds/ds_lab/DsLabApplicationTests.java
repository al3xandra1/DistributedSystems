package gr.hua.dit.ds.ds_lab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
