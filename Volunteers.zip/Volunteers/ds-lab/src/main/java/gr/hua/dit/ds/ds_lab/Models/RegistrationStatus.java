package gr.hua.dit.ds.ds_lab.Models;

// Καταστάσεις για την εγγραφή
public enum RegistrationStatus {
    PENDING,    // Υπό εξέταση
    APPROVED,   // Εγκρίθηκε
    REJECTED    // Απορρίφθηκε
}

