package Registration.Status;

public class APPROVED {
    private final String status = "APPROVED";

    public String getStatus() {
        return status;
    }
}
