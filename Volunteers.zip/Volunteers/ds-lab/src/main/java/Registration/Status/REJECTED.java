package Registration.Status;

public class REJECTED {
    private final String status = "REJECTED";

    public String getStatus() {
        return status;
    }


}
